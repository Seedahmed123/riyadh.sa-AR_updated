// Configuration
const CONFIG = {
  USE_MOCK_LOCATIONS: true,
  SEARCH_RADIUS_KM: 1, // 1km radius
  MIN_DISTANCE_METERS: 5,
  GPS_TIMEOUT: 10000, // 10 seconds
  DEBUG_MODE: true,
};

// State Management
const State = {
  currentLocation: null,
  currentLanguage: 'en',
  isInitialized: false,
  markersAdded: false,
  isLoading: false,
  gpsReady: false,
  sceneReady: false,
};

// Translations
const TRANSLATIONS = {
  en: {
    error: "Error",
    close: "Close",
    loading: "Loading...",
    initializingAR: "Initializing AR...",
    gettingLocation: "Getting your location...",
    requestingCamera: "Requesting camera access...",
    loadingLocations: "Loading nearby locations...",
    deviceNotSupported: "AR works only on mobile devices with camera.",
    locationRequired: "Location permission is required for AR experience.",
    cameraRequired: "Camera permission is required for AR experience.",
    noLocations: "No AR locations found nearby.",
    gpsTimeout: "GPS is taking longer than expected. Using approximate location.",
    gpsAcquired: "GPS location acquired successfully.",
    debugInfo: "GPS Status: ",
  },
  ar: {
    error: "خطأ",
    close: "إغلاق",
    loading: "جاري التحميل...",
    initializingAR: "جاري تهيئة الواقع المعزز...",
    gettingLocation: "جاري تحديد موقعك...",
    requestingCamera: "جاري طلب إذن الكاميرا...",
    loadingLocations: "جاري تحميل المواقع القريبة...",
    deviceNotSupported: "الواقع المعزز يعمل على الجوالات التي تحتوي على كاميرا فقط.",
    locationRequired: "يتطلب السماح بخدمة الموقع لتجربة الواقع المعزز.",
    cameraRequired: "يتطلب السماح بالكاميرا لتجربة الواقع المعزز.",
    noLocations: "لا توجد مواقع قريبة للعرض.",
    gpsTimeout: "تحديد الموقع يستغرق وقتاً أطول من المتوقع. سيتم استخدام موقع تقريبي.",
    gpsAcquired: "تم تحديد الموقع بنجاح.",
    debugInfo: "حالة الموقع: ",
  }
};

// DOM Elements Cache
const DOM = {
  loader: null,
  loaderText: null,
  scene: null,
  camera: null,
  popup: null,
  debugInfo: null,
  languageButtons: null,
  
  init: function() {
    this.loader = document.getElementById('rd-loader');
    this.loaderText = document.getElementById('loader-text');
    this.scene = document.querySelector('a-scene');
    this.camera = document.querySelector('[gps-camera]');
    this.popup = document.getElementById('popup');
    this.debugInfo = document.getElementById('debug-info');
    this.languageButtons = document.querySelectorAll('.lang-btn');
    
    // Initialize language buttons
    this.languageButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const lang = btn.dataset.lang;
        this.setActiveLanguage(lang);
        UI.updatePopupTexts();
        if (State.isInitialized) {
          LocationManager.loadNearbyLocations();
        }
      });
    });
  },
  
  setActiveLanguage: function(lang) {
    this.languageButtons.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.lang === lang);
    });
  }
};

// UI Controller
const UI = {
  updateLoaderText: function(textKey) {
    if (DOM.loaderText) {
      DOM.loaderText.textContent = TRANSLATIONS[State.currentLanguage][textKey];
    }
  },
  
  showLoader: function() {
    State.isLoading = true;
    if (DOM.loader) {
      DOM.loader.classList.remove('rd-loader--hidden');
    }
  },
  
  hideLoader: function() {
    State.isLoading = false;
    if (DOM.loader) {
      setTimeout(() => {
        DOM.loader.classList.add('rd-loader--hidden');
      }, 500);
    }
  },
  
  showPopup: function(messageKey) {
    const message = TRANSLATIONS[State.currentLanguage][messageKey] || messageKey;
    DOM.popup.querySelector('p').textContent = message;
    DOM.popup.style.display = 'block';
  },
  
  updatePopupTexts: function() {
    if (DOM.popup) {
      DOM.popup.querySelector('h2').textContent = TRANSLATIONS[State.currentLanguage].error;
      DOM.popup.querySelector('button').textContent = TRANSLATIONS[State.currentLanguage].close;
    }
  },
  
  closePopup: function() {
    DOM.popup.style.display = 'none';
  },
  
  updateDebugInfo: function(message) {
    if (DOM.debugInfo && CONFIG.DEBUG_MODE) {
      const prefix = TRANSLATIONS[State.currentLanguage].debugInfo;
      DOM.debugInfo.textContent = prefix + message;
    }
  },
  
  setLanguage: function(lang) {
    if (!TRANSLATIONS[lang]) return;
    
    State.currentLanguage = lang;
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    DOM.setActiveLanguage(lang);
    this.updatePopupTexts();
    this.updateLoaderText('initializingAR');
  }
};

// Device & Permission Manager
const PermissionManager = {
  isMobileDevice: function() {
    return /ios|Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  },
  
  getDeviceInfo: async function() {
    try {
      if (typeof TWK !== 'undefined' && TWK.getDeviceInfo) {
        const response = await TWK.getDeviceInfo();
        const info = response.result || response;
        console.log('Device info:', info);
        return info;
      }
      return {
        device_model: navigator.userAgent,
        app_language: navigator.language.startsWith('ar') ? 'ar' : 'en'
      };
    } catch (e) {
      console.error('Device info error:', e);
      return null;
    }
  },
  
  getUserLocation: async function() {
    try {
      if (typeof TWK !== 'undefined' && TWK.getUserLocation) {
        const response = await TWK.getUserLocation();
        const data = response.result || response;
        
        if (data.location?.latitude && data.location?.longitude) {
          return {
            latitude: Number(data.location.latitude),
            longitude: Number(data.location.longitude),
            accuracy: data.location.accuracy
          };
        }
      }
      
      // Fallback to browser geolocation
      return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
          reject(new Error('Geolocation not supported'));
          return;
        }
        
        navigator.geolocation.getCurrentPosition(
          (position) => {
            resolve({
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              accuracy: position.coords.accuracy
            });
          },
          (error) => {
            reject(error);
          },
          { 
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          }
        );
      });
    } catch (e) {
      console.error('Location error:', e);
      throw e;
    }
  },
  
  getCameraPermission: async function() {
    try {
      if (typeof TWK !== 'undefined' && TWK.askCameraPermission) {
        const response = await TWK.askCameraPermission();
        const data = response.result || response;
        return data.granted === true;
      }
      
      // Fallback to browser media permissions
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
          } 
        });
        stream.getTracks().forEach(track => track.stop());
        return true;
      } catch (e) {
        console.error('Camera access error:', e);
        return false;
      }
    } catch (e) {
      console.error('Camera permission error:', e);
      return false;
    }
  }
};

// Location Data Manager
const LocationManager = {
  getMockLocations: function(baseLocation) {
    const locations = [];
    const baseLat = baseLocation.latitude;
    const baseLon = baseLocation.longitude;
    
    // Generate 3-5 mock locations around the user
    const count = Math.floor(Math.random() * 3) + 3;
    
    for (let i = 0; i < count; i++) {
      const angle = (i * 2 * Math.PI) / count;
      const distance = 100 + Math.random() * 400; // 100-500 meters
      const latOffset = (distance * Math.cos(angle)) / 111320;
      const lonOffset = (distance * Math.sin(angle)) / (111320 * Math.cos(baseLat * Math.PI / 180));
      
      locations.push({
        latitude: baseLat + latOffset,
        longitude: baseLon + lonOffset,
        label: State.currentLanguage === 'ar' 
          ? `موقع تجريبي ${i + 1}` 
          : `Test Location ${i + 1}`,
        distance: Math.round(distance),
        type: i % 2 === 0 ? 'project' : 'metro',
        description: State.currentLanguage === 'ar'
          ? 'وصف الموقع التجريبي'
          : 'Test location description'
      });
    }
    
    return locations;
  },
  
  buildApiUrl: function(lat, lon) {
    const radius = CONFIG.SEARCH_RADIUS_KM * 0.009; // Convert km to degrees
    return `https://twk-services.rcrc.gov.sa/momentprojects.php?_format=json&types[]=projects&types[]=metro_stations&langcode=${State.currentLanguage}&lat[min]=${lat - radius}&lat[max]=${lat + radius}&lon[min]=${lon - radius}&lon[max]=${lon + radius}&on_ar=1`;
  },
  
  fetchAPILocations: async function(apiUrl) {
    try {
      console.log('Fetching locations from:', apiUrl);
      const response = await fetch(apiUrl, {
        headers: {
          'Accept': 'application/json',
        },
        timeout: 10000
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const data = await response.json();
      console.log('API Response:', data);
      
      const items = data?.result?.items || [];
      return items
        .filter(item => item.geofield?.lat && item.geofield?.lon)
        .map(item => ({
          latitude: Number(item.geofield.lat),
          longitude: Number(item.geofield.lon),
          label: item.title || 'Unknown Location',
          distance: item.distance || 0,
          type: item.type || 'project',
          description: item.description || ''
        }));
    } catch (error) {
      console.error('API fetch error:', error);
      return [];
    }
  },
  
  loadNearbyLocations: async function() {
    if (!State.currentLocation) {
      console.error('No current location available');
      return [];
    }
    
    UI.updateLoaderText('loadingLocations');
    
    let locations = [];
    
    // Try API first
    if (!CONFIG.USE_MOCK_LOCATIONS) {
      const apiUrl = this.buildApiUrl(
        State.currentLocation.latitude,
        State.currentLocation.longitude
      );
      locations = await this.fetchAPILocations(apiUrl);
    }
    
    // Fallback to mock data if API returns nothing or in debug mode
    if (locations.length === 0) {
      console.log('Using mock locations');
      locations = this.getMockLocations(State.currentLocation);
    }
    
    console.log(`Loaded ${locations.length} locations`);
    return locations;
  },
  
  calculateDistance: function(lat1, lon1, lat2, lon2) {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;
    
    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    
    return R * c; // Distance in meters
  }
};

// AR Scene Manager
const ARManager = {
  clearMarkers: function() {
    const scene = DOM.scene;
    if (!scene) return;
    
    const markers = scene.querySelectorAll('[gps-entity-place]');
    markers.forEach(marker => marker.remove());
    State.markersAdded = false;
  },
  
  createMarker: function(location, index) {
    const marker = document.createElement('a-entity');
    const distance = Math.round(location.distance);
    
    // Set GPS position
    marker.setAttribute('gps-entity-place', {
      latitude: location.latitude,
      longitude: location.longitude
    });
    
    // Make it look at camera
    marker.setAttribute('look-at', '[gps-camera]');
    
    // Unique ID for the marker
    marker.setAttribute('id', `marker-${index}`);
    
    // Container for the marker content
    const container = document.createElement('a-entity');
    container.setAttribute('position', '0 0 0');
    
    // Background circle
    const circle = document.createElement('a-circle');
    circle.setAttribute('radius', '0.8');
    circle.setAttribute('color', location.type === 'metro' ? '#3498db' : '#5c8a12');
    circle.setAttribute('opacity', '0.9');
    circle.setAttribute('position', '0 1.2 0');
    container.appendChild(circle);
    
    // Icon based on type
    const icon = document.createElement('a-text');
    icon.setAttribute('value', location.type === 'metro' ? '🚇' : '🏗️');
    icon.setAttribute('align', 'center');
    icon.setAttribute('position', '0 1.2 0.1');
    icon.setAttribute('scale', '2 2 2');
    container.appendChild(icon);
    
    // Label text
    const label = document.createElement('a-text');
    label.setAttribute('value', location.label);
    label.setAttribute('align', 'center');
    label.setAttribute('color', '#FFFFFF');
    label.setAttribute('position', '0 2 0');
    label.setAttribute('scale', '1.5 1.5 1.5');
    label.setAttribute('width', '4');
    label.setAttribute('wrap-count', '20');
    label.setAttribute('z-offset', '0.5');
    container.appendChild(label);
    
    // Distance indicator
    const distanceText = document.createElement('a-text');
    distanceText.setAttribute('value', `${distance}m`);
    distanceText.setAttribute('align', 'center');
    distanceText.setAttribute('color', '#CCCCCC');
    distanceText.setAttribute('position', '0 0.5 0');
    distanceText.setAttribute('scale', '1 1 1');
    container.appendChild(distanceText);
    
    // Connecting line
    const line = document.createElement('a-cylinder');
    line.setAttribute('height', '1');
    line.setAttribute('radius', '0.05');
    line.setAttribute('color', '#5c8a12');
    line.setAttribute('opacity', '0.6');
    line.setAttribute('position', '0 0.5 0');
    container.appendChild(line);
    
    // Add click handler
    marker.setAttribute('class', 'clickable-marker');
    marker.addEventListener('click', () => {
      this.onMarkerClick(location);
    });
    
    marker.appendChild(container);
    return marker;
  },
  
  addMarkers: function(locations) {
    if (State.markersAdded) {
      this.clearMarkers();
    }
    
    const scene = DOM.scene;
    if (!scene) {
      console.error('Scene not found');
      return;
    }
    
    locations.forEach((location, index) => {
      const marker = this.createMarker(location, index);
      scene.appendChild(marker);
    });
    
    State.markersAdded = true;
    console.log(`Added ${locations.length} markers to scene`);
  },
  
  onMarkerClick: function(location) {
    console.log('Marker clicked:', location);
    // You can add custom behavior here, like showing a detailed view
    alert(`${location.label}\nDistance: ${location.distance}m\nType: ${location.type}`);
  },
  
  initializeScene: function(locations) {
    if (!DOM.scene || !DOM.camera) {
      console.error('AR scene elements not found');
      return;
    }
    
    // Wait for scene to load
    if (DOM.scene.hasLoaded) {
      this.onSceneReady(locations);
    } else {
      DOM.scene.addEventListener('loaded', () => {
        this.onSceneReady(locations);
      });
    }
    
    // Listen for GPS updates
    DOM.camera.addEventListener('gps-camera-update-position', (event) => {
      if (!State.gpsReady) {
        State.gpsReady = true;
        State.currentLocation = {
          latitude: event.detail.position.latitude,
          longitude: event.detail.position.longitude
        };
        UI.updateDebugInfo(TRANSLATIONS[State.currentLanguage].gpsAcquired);
        console.log('GPS position updated:', State.currentLocation);
      }
    });
    
    // GPS timeout
    setTimeout(() => {
      if (!State.gpsReady) {
        UI.updateDebugInfo(TRANSLATIONS[State.currentLanguage].gpsTimeout);
        console.warn('GPS timeout - using initial location');
        
        // Add markers even if GPS isn't ready yet
        if (!State.markersAdded && locations.length > 0) {
          this.addMarkers(locations);
          UI.hideLoader();
        }
      }
    }, CONFIG.GPS_TIMEOUT);
  },
  
  onSceneReady: function(locations) {
    State.sceneReady = true;
    console.log('AR scene ready');
    
    // If GPS is already ready, add markers immediately
    if (State.gpsReady && locations.length > 0) {
      this.addMarkers(locations);
      UI.hideLoader();
    } else if (locations.length > 0) {
      // Wait a bit for GPS, then add markers
      setTimeout(() => {
        this.addMarkers(locations);
        UI.hideLoader();
      }, 2000);
    } else {
      UI.hideLoader();
    }
  }
};

// Main Application Initialization
const App = {
  async initialize() {
    try {
      // Initialize DOM
      DOM.init();
      
      // Show loader
      UI.showLoader();
      UI.updateLoaderText('initializingAR');
      
      // Get device info
      const deviceInfo = await PermissionManager.getDeviceInfo();
      if (deviceInfo?.app_language) {
        UI.setLanguage(deviceInfo.app_language);
      }
      
      // Check if mobile device
      if (!PermissionManager.isMobileDevice()) {
        throw 'deviceNotSupported';
      }
      
      // Get user location
      UI.updateLoaderText('gettingLocation');
      const location = await PermissionManager.getUserLocation();
      State.currentLocation = location;
      console.log('User location:', location);
      UI.updateDebugInfo('Location acquired');
      
      // Get camera permission
      UI.updateLoaderText('requestingCamera');
      const cameraGranted = await PermissionManager.getCameraPermission();
      if (!cameraGranted) {
        throw 'cameraRequired';
      }
      
      // Load nearby locations
      UI.updateLoaderText('loadingLocations');
      const locations = await LocationManager.loadNearbyLocations();
      
      if (locations.length === 0) {
        throw 'noLocations';
      }
      
      // Initialize AR scene with locations
      ARManager.initializeScene(locations);
      
      State.isInitialized = true;
      
    } catch (error) {
      console.error('Initialization error:', error);
      UI.hideLoader();
      
      if (typeof error === 'string' && TRANSLATIONS[State.currentLanguage][error]) {
        UI.showPopup(error);
      } else if (error instanceof Error) {
        UI.showPopup(error.message);
      } else {
        UI.showPopup('Initialization failed. Please try again.');
      }
    }
  },
  
  restartAR: async function() {
    UI.showLoader();
    UI.updateLoaderText('initializingAR');
    ARManager.clearMarkers();
    State.gpsReady = false;
    State.sceneReady = false;
    State.markersAdded = false;
    
    const locations = await LocationManager.loadNearbyLocations();
    if (locations.length > 0) {
      ARManager.initializeScene(locations);
    } else {
      UI.hideLoader();
      UI.showPopup('noLocations');
    }
  }
};

// Global functions for HTML event handlers
window.closePopup = function() {
  UI.closePopup();
};

// Initialize the app when DOM is loaded
window.addEventListener('DOMContentLoaded', () => {
  App.initialize();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && State.isInitialized) {
    // Page became visible again, refresh locations
    App.restartAR();
  }
});

// Export for debugging
if (CONFIG.DEBUG_MODE) {
  window.App = App;
  window.State = State;
  window.ARManager = ARManager;
  window.LocationManager = LocationManager;
}